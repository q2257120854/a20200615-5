<?php
$down_url = base64_decode($_GET['url']);
$sitename = $_GET['site'];
?>
<!doctype html>
<html lang="zh-cn">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=0.5, maximum-scale=2.0, user-scalable=yes" />
<title>页面跳转...寻书网</title>
<script>
function gotopage(){
		location.href = "<?php echo $down_url;?>";
}
window.setTimeout("gotopage()",3000); 
</script>
<link href="/down/index.css" rel="stylesheet" type="text/css" />
</head>
<body>
<div class="wrapper">
    <div class="content mt20">
            <div class="okremind mb10">
                <h3><b>提醒：</b></h3>
                <b>寻书网</b>不存储任何小说内容，正在跳转至<b><?php echo $sitename;?></b>下载本书。                <br/><br/>书籍正在打包中......请稍后。<br/><br/>
                <p>页面将在<em class="red">5s</em>后自动跳转；</p>
                <p>若没有自动跳转，<a href="<?php echo $down_url;?>">点击立即跳转...</a></p>
            </div>
    </div>
    <div style="display:none;"></div>
</div>
</body>
</html>