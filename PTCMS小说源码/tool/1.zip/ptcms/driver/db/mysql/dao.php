<?php
class Driver_Db_Mysql_Dao extends Driver_Db_Dao{

}