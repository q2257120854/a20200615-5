<?php
class BccsServerException extends Exception
{
    //do nothing
}
?>
