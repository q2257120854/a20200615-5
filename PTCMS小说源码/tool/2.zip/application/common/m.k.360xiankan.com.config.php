<?php
return array (
  'tpl_theme' => 'wap_xunshu5',
  'html' => 0,
);