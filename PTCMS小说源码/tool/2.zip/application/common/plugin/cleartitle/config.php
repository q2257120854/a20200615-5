<?php
return array (
  0 => 
  array (
    'title' => '选项',
    'key' => 'key1',
    'intro' => '',
    'value' => 'value',
    'type' => 'text',
    'extra' => '',
  ),
);