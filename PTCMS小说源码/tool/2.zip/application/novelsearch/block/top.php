<?php
class TopBlock extends PT_Block{ public function run($zym_5) { return $this->pt->model('top')->getlist(); } }
?>