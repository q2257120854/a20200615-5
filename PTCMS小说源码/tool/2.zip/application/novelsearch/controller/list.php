<?php
class listController extends CommonController {
    public function topAction() {
        $zym_8 = I('get.type', 'en', 'lastupdate');
        $zym_6 = $this->model('top')->getlist();
        $this->view->page = I('get.page', 'int', 1);
        $this->view->pagesize = C('pagesize_toplist');
        $this->view->totalnum = M('novelsearch_info')->getcount(array());
        $this->view->toplist = M('novelsearch_info')->getpagelist(array() , $zym_8, $this->view->page, $this->view->pagesize);
        $this->view->pageurl = U('novelsearch.list.top', array(
            'type' => $zym_8,
            'page' => '__PAGE__'
        ));
        $this->view->top = array(
            'key' => $zym_8,
            'name' => $zym_6[$zym_8]['name'],
            'url' => $zym_6[$zym_8]['url']
        );
        $this->display('top');
    }
    public function articleAjax() {
        $zym_8 = M('novelsearch_info');
        $start = I('post.start'); 
        $list = $zym_8->limit($start, 2)->order('id asc')->select(); 
        $this->ajaxReturn(array( 'result'=>$list,'status'=>1, 'msg'=>'获取成功！')); 
    }
    public function categoryAction() {
        $zym_8 = I('get.key', 'en', 'all');
        $zym_9 = M('category')->getinfobykey($zym_8);
        $zym_7 = array();
        if ($zym_8 != 'all') $zym_7 = array(
            'categoryid' => $zym_9['id']
        );
        $this->view->category = $this->view->info = $zym_9;
        $this->view->page = I('get.page', 'int', 1);
        $this->view->pagesize = C('pagesize_categorylist');
        $this->view->totalnum = M('novelsearch_info')->getcount($zym_7);
        $this->view->categorylist = $this->view->list = M('novelsearch_info')->getpagelist($zym_7, 'lastupdate', $this->view->page, $this->view->pagesize);
        $this->view->pageurl = U('novelsearch.list.category', array(
            'key' => $zym_8,
            'page' => '__PAGE__'
        ));
        $this->display('category');
    }
    public function overAction() {
        $zym_5 = new NovelSearch_infoModel();
        $this->view->page = I('get.page', 'int', 1);
        $this->view->pagesize = C('pagesize_toplist');
        $this->view->totalnum = $zym_5->getcount(['isover' => 1]);
        $this->view->overlist = $zym_5->getpagelist(['isover' => 1], 'lastupdate', $this->view->page, $this->view->pagesize);
        $this->view->pageurl = U('novelsearch.list.over', array(
            'page' => '__PAGE__'
        ));
        $this->display('over');
    }
}
?>
