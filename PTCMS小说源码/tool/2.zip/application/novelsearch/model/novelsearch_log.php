<?php
 class NovelSearch_LogModel extends Model { }
?>