<?php
return array (
  'sitemap_num' => '200',
  'sitemap_mode' => '1',
  'ping_power' => '1',
  'ping_site' => 'www.kuaiyankanshu.net',
  'ping_token' => 'vgJ0NqL5SmbpqkNV',
);