<?php
class habbitController extends UserController{ public function indexAction() { $this->error('正在施工中！'); } }
?>