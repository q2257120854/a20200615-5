<?php
class indexController extends CommonController{ public function indexAction() { $this->display('index'); } }
?>