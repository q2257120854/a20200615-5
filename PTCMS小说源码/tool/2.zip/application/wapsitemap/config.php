<?php
return array (
  'sitemap_num' => '1000',
  'sitemap_mode' => '0',
  'ping_power' => '1',
  'ping_site' => 'https://m.677a.cn',
  'ping_token' => 'vgJ0NqL5SmbpqkNV',
);