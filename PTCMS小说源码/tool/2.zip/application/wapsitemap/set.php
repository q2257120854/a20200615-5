<?php
return array (
  0 => 
  array (
    'title' => '每页小说数量',
    'key' => 'sitemap_num',
    'intro' => '',
    'value' => '1000',
    'type' => 'text',
    'extra' => '',
  ),
  1 => 
  array (
    'title' => 'sitemap模式',
    'key' => 'sitemap_mode',
    'intro' => '',
    'value' => '0',
    'type' => 'radio',
    'extra' => '0:简单模式
1:详细模式',
  ),
  2 => 
  array (
    'title' => '主动提交开关',
    'key' => 'ping_power',
    'intro' => '',
    'value' => '1',
    'type' => 'radio',
    'extra' => '1:开启
0:关闭',
  ),
  3 => 
  array (
    'title' => '主动提交site',
    'key' => 'ping_site',
    'intro' => '',
    'value' => 'https://m.677a.cn',
    'type' => 'text',
    'extra' => '',
  ),
  4 => 
  array (
    'title' => '主动提交token',
    'key' => 'ping_token',
    'intro' => '',
    'value' => 'vgJ0NqL5SmbpqkNV',
    'type' => 'text',
    'extra' => '',
  ),
);