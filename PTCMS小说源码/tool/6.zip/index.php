<?php
/***************************************************************
 *   Program: 小说聚合程序PTNovelJuhe
 *   Version: 2.0.3
 *   WebSite: http://www.677a.cn
 *   License: http://www.677a.cn/help/license
 * Copyright: 2018 - 2026 Ptcms Studio
 *      Date: 2018-02-26 14:58:56
 *      File: index.php
 **************************************************************/


define('PRONAME', '小说聚合程序');
define('PROENNAME', 'PTNovelJuhe');
define('PROVERSION', '3.0.2');
define('PROTIME', '20180512');



include dirname(__FILE__).'/ptcms/ptcms.php';