<?php
$i=1;
$urls = array();
for($i =22665; $i< 22675; $i++) 
{    
$urls[$i] = "https://m.677a.cn/" .$i;
}  
$api = 'http://data.zz.baidu.com/urls?appid=1611239085560134&token=U1bmMJfyb3f7fNnk&type=realtime';
$ch = curl_init();
$options =  array(
    CURLOPT_URL => $api,
    CURLOPT_POST => true,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POSTFIELDS => implode("\n", $urls),
    CURLOPT_HTTPHEADER => array('Content-Type: text/plain'),
);
curl_setopt_array($ch, $options);
$result = curl_exec($ch);
echo $result;
?>